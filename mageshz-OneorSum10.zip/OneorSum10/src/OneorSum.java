//author:Mageshz
//date:4th may 2017 at 5:57 pm
//mentor:JAMES
public class OneorSum {

	public static boolean isOneOrSum10(int a,int b) {
		if((a==10)||(b==10)||(a+b==10)){
			return true;
		}else
		{
			return false;
		}
	}
	public static void main(String args[]) {
		boolean result=isOneOrSum10(10, 0);
		System.out.println(""+result);
		boolean result1=isOneOrSum10(9, 10);
		System.out.println(""+result1);
		boolean result2=isOneOrSum10(9,9);
		System.out.println(""+result2);
		boolean result3=isOneOrSum10(1, 9);
		System.out.println(""+result3);
	
	}

}
