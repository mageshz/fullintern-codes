//mentor:James
//author:Mageshz
//date and time: 6/5/2017 at 9 PM
//This is about PosNeg challenge
public class PosNeg {
	public static boolean check(int a, int b, boolean c) {
		if (((a < 0 && b > 0) || (a > 0 && b < 0))&&(c==false)) {
		
			return true;
		}

		else if (c == true) {
			if ((a < 0) && (b < 0)) {
				return true;
			}
		}

		return false;
	}

	public static void main(String args[]) {
		boolean result = PosNeg.check(1, -1, false);
		System.out.println("" + result);
		boolean resul = PosNeg.check(-1, 1, false);
		System.out.println("" + resul);
		boolean reult = PosNeg.check(1, 1, false);
		System.out.println("" + reult);
		boolean esult = PosNeg.check(-1, -1, false);
		System.out.println("" + esult);
		boolean result1 = PosNeg.check(-1, -1, true);
		System.out.println("" + result1);
		boolean result2 = PosNeg.check(-1, 1, true);
		System.out.println("" + result2);
		boolean result3 = PosNeg.check(1, 1, true);
		System.out.println("" + result3);

	}
}

